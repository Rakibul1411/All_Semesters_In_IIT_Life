#include <iostream>
#include <thread>
#include <vector>
#include <semaphore.h>
#include <mutex>
#include <condition_variable>

// Shared data
int num_slices = 0;
const int S = 8; // Number of slices per pizza
std::mutex mutex;
std::condition_variable pizza_ready;
sem_t pizza;     // Semaphore for the number of available pizza slices
sem_t deliver;   // Semaphore to signal the delivery thread
bool order_in_progress = false; // Flag to indicate if an order is in progress

// Function for student thread
void student_thread(int id) {
    while (true) {
        sem_wait(&pizza); // Wait for a slice of pizza to be available

        std::unique_lock<std::mutex> lock(mutex);
        if (num_slices == 0) {
            if (!order_in_progress) {
                // If this student is the first to find no pizza, order a new one
                order_in_progress = true;
                std::cout << "Student " << id << " finds no pizza and orders a new one.\n";
                sem_post(&deliver);
            }
            // Wait until pizza is delivered
            std::cout << "Student " << id << " is going to sleep until new pizza arrives.\n";
            pizza_ready.wait(lock, []{ return num_slices > 0; });
        }

        // Pick up a slice of pizza
        num_slices--;
        std::cout << "Student " << id << " is eating a slice of pizza. Slices left: " << num_slices << std::endl;
        lock.unlock();

        // Simulate studying while eating pizza
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
}

// Function for delivery thread
void delivery_thread() {
    while (true) {
        // Wait for a signal to deliver pizza
        sem_wait(&deliver);

        // Prepare and deliver pizza
        std::this_thread::sleep_for(std::chrono::milliseconds(2000)); // Simulate pizza delivery time

        std::unique_lock<std::mutex> lock(mutex);
        num_slices = S; // Reset the number of slices
        order_in_progress = false; // Reset the order in progress flag
        std::cout << "Pizza delivered with " << num_slices << " slices." << std::endl;
        lock.unlock();

        // Signal that pizza is ready
        pizza_ready.notify_all();

        // Release all slices in the semaphore
        for (int i = 0; i < S; ++i) {
            sem_post(&pizza);
        }
    }
}

int main() {
    const int num_students = 5;

    // Initialize semaphores
    sem_init(&pizza, 0, 0);
    sem_init(&deliver, 0, 0);

    // Create student threads
    std::vector<std::thread> students;
    for (int i = 0; i < num_students; ++i) {
        students.push_back(std::thread(student_thread, i + 1));
    }

    // Create delivery thread
    std::thread delivery(delivery_thread);

    // Join threads (in a real application, you'd likely have a different exit condition)
    for (auto& student : students) {
        student.join();
    }
    delivery.join();

    // Destroy semaphores
    sem_destroy(&pizza);
    sem_destroy(&deliver);

    return 0;
}
