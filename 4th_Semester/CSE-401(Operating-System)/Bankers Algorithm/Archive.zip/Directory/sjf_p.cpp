#include<iostream>
using namespace std;
int main(){

    queue<string>process;
    return 0;
}