#include <iostream>
#include <thread>
#include <vector>
#include <semaphore.h>
#include <mutex>
#include <unistd.h> // for sleep

// Define shared resources and synchronization primitives
const int S = 8; // Number of slices per pizza
sem_t pizza; // Semaphore to track available pizza slices
sem_t deliver; // Semaphore to ensure pizza is ordered exactly once
int num_slices = 0; // Number of remaining pizza slices
std::mutex mutex; // Mutex to protect access to num_slices
bool must_study = true; // Condition for students to keep studying

void student(int id) {
    while (must_study) {
        // Try to pick up a piece of pizza
        sem_wait(&pizza);

        // Lock to safely check and update num_slices
        std::lock_guard<std::mutex> lock(mutex);
        if (num_slices > 0) {
            // Student eats a slice of pizza
            num_slices--;
            std::cout << "Student " << id << " is eating a slice. Slices left: " << num_slices << std::endl;
            if (num_slices == 0) {
                // If no slices left, order new pizza
                sem_post(&deliver);
            }
        }
    }
}

void delivery() {
    while (true) {
        // Wait until a new pizza needs to be delivered
        sem_wait(&deliver);

        // Simulate pizza preparation time
        std::cout << "Preparing a new pizza..." << std::endl;
        sleep(2); // Simulate the time to prepare and deliver a pizza

        // Lock to safely update num_slices
        std::lock_guard<std::mutex> lock(mutex);
        num_slices = S;
        std::cout << "A new pizza has arrived with " << S << " slices." << std::endl;

        // Signal the availability of new pizza slices
        for (int i = 0; i < S; ++i) {
            sem_post(&pizza);
        }
    }
}

int main() {
    // Initialize semaphores
    sem_init(&pizza, 0, 0); // No pizza slices initially
    sem_init(&deliver, 0, 1); // Allow the first delivery

    // Create student threads
    const int num_students = 5;
    std::vector<std::thread> students;
    for (int i = 0; i < num_students; ++i) {
        students.emplace_back(student, i + 1);
    }

    // Create delivery thread
    std::thread delivery_thread(delivery);

    // Simulate studying for a certain duration
    sleep(10);
    must_study = false; // Stop the students from studying

    // Join student threads
    for (auto& student_thread : students) {
        student_thread.join();
    }

    // We might need to stop the delivery thread gracefully
    // Depending on the implementation, you might need to add a mechanism to stop the delivery thread
    delivery_thread.detach();

    // Clean up semaphores
    sem_destroy(&pizza);
    sem_destroy(&deliver);

    std::cout << "Study session is over." << std::endl;
    return 0;
}
