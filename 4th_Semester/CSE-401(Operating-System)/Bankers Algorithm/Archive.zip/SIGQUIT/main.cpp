#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>

void handle_sigquit(int sig) {
    printf("Caught signal %d (SIGQUIT), exiting gracefully...\n", sig);
    exit(0);
}

void* signal_handler_thread(void* arg) {
    sigset_t* set = (sigset_t*)arg;
    int sig;

    // Wait for a signal to be delivered
    if (sigwait(set, &sig) != 0) {
        perror("sigwait failed");
        pthread_exit(NULL);
    }

    // Handle the signal
    if (sig == SIGQUIT) {
        handle_sigquit(sig);
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t thread;
    sigset_t set;
    struct sigaction sa;

    // Block SIGQUIT in the main thread and all other threads
    sigemptyset(&set);
    sigaddset(&set, SIGQUIT);
    if (pthread_sigmask(SIG_BLOCK, &set, NULL) != 0) {
        perror("pthread_sigmask failed");
        exit(1);
    }

    // Set up the SIGQUIT handler
    sa.sa_handler = handle_sigquit;
    sa.sa_flags = 0;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGQUIT, &sa, NULL) != 0) {
        perror("sigaction failed");
        exit(1);
    }

    // Create a thread to handle the signals
    if (pthread_create(&thread, NULL, signal_handler_thread, (void*)&set) != 0) {
        perror("pthread_create failed");
        exit(1);
    }

    printf("Process running. Press Ctrl+\\ (SIGQUIT) to terminate it...\n");

    // Infinite loop to keep the program running
    while (1) {
        sleep(1);
    }

    return 0;
}
